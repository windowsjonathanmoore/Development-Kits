Reset 5.00 -WiNBETA

Once installed, Reset 5.00 will completely hide the unactivated state of your OS from you, it will never ask to be activated.

This version of Reset will work on Windows XP and XP SP1 Professional and Home Edition,
and Windows .NET up to RC1 (3663).

INSTRUCTIONS:
1. Boot into Safe Mode (press F8 at boot menu)
2. Click Install
2. Reboot, reset will take place from first reboot from normal mode

To install Reset on an expired OS, just boot into safe mode, and follow above


------------------------

Improvements since 4.12:
WPA is completely hidden, you'd never know it wasn't activated ;D
you will never be asked to activate
You can log on after 14 days uptime
proper support for xp home
it runs nicer :)

There are two exceptions, where windows will ask to be activated:
1, very unlikely
Crash/turn off without proper shutdown, then next bootup 14 (or whatever your grace period is) days after the last bootup
Windows will say you have to activate before you can log on, click cancel to shutdown the machine, then windows will be unlocked
again from the next boot
2, more likely
If you have an uptime greater than the grace period, and you do Switch User, you will not be able to log onto any new sessions without 
logging off all other sessions, but you will be able to reconnect to any active sessions